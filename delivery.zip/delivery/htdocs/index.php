<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shipment Tracking</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f4f4f4;
        }

        .section {
            position: relative;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5); /* Adds the blur effect */
            backdrop-filter: blur(5px);
            z-index: 1;
            border-radius: 10px;
        }

        .section-content {
            position: relative;
            z-index: 2;
        }

        .carousel {
            margin-top: 20px;
        }

        .btn-outline-secondary {
            color: white;
            border-color: white;
        }

        .btn-outline-secondary:hover {
            background-color: white;
            color: black;
        }
    </style>
</head>
<?php include('delivery/header.php') ?>
<body>
    <div class="container">
        <!-- Section 1: Track Shipment -->
        <div class="row justify-content-center">
            <div class="col-md-6 section" style="background-image: url('images/images (78).jpeg');">
                <div class="section-content">
                    <h3>Track Your Shipment</h3>
                    <p>Enter your tracking number below to get real-time updates on your shipment.</p>
                    <form action="delivery/public/track.php" method="GET">
                        <div class="mb-3">
                            <label for="tracking_number" class="form-label">Tracking Number</label>
                            <input type="text" class="form-control" id="tracking_number" name="tracking_number" placeholder="Enter your tracking number" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Track</button>
                    </form>

                    <!-- Sliding Images -->
                    <div id="carouselExampleIndicators" class="carousel slide mt-4" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                             <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
                              <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="4" aria-label="Slide 5"></button>
                              <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="5" aria-label="Slide 6"></button>
                              <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="6" aria-label="Slide 7"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="images/slide1.jpeg" class="d-block w-100" alt="Slider Image 1">
                            </div>
                            <div class="carousel-item">
                                <img src="images/slide2.png" class="d-block w-100" alt="Slider Image 2">
                            </div>
                            <div class="carousel-item">
                                <img src="images/slide3.jpg" class="d-block w-100" alt="Slider Image 3">
                            </div>
                             <div class="carousel-item">
                                <img src="images/slide4.jpeg" class="d-block w-100" alt="Slider Image 4">
                            </div>
                             <div class="carousel-item">
                                <img src="images/slide5.jpeg" class="d-block w-100" alt="Slider Image 5">
                            </div>
                            <div class="carousel-item">
                                <img src="images/slide6.jpeg" class="d-block w-100" alt="Slider Image 6">
                            </div>
                            <div class="carousel-item">
                                <img src="images/slide7.jpeg" class="d-block w-100" alt="Slider Image 7">
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 2-6: Additional Options -->
        <div class="row">
            <div class="col-md-4 section" style="background-image: url('images/images (70).jpeg');">
                <div class="section-content text-center">
                    <h5>Login Now</h5>
                    <p>View your shipment anytime.</p>
                    <a href="delivery/public/login.php" class="btn btn-outline-secondary">Login</a>
                </div>
            </div>
            <div class="col-md-4 section" style="background-image: url('images/images (93).jpeg');">
                <div class="section-content text-center">
                    <h5>Register Now</h5>
                    <p>Welcome! Join our shipment today.</p>
                    <a href="delivery/public/register.php" class="btn btn-outline-secondary">Register Now</a>
                </div>
            </div>
            <div class="col-md-4 section" style="background-image: url('images/images (97).jpeg');">
                <div class="section-content text-center">
                    <h5>Schedule a Pickup</h5>
                    <p>Arrange for a team to pick up your shipment at your convenience.</p>
                    <a href="#" class="btn btn-outline-secondary">Learn More</a>
                </div>
            </div>
            <div class="col-md-4 section" style="background-image: url('images/images (78).jpeg');">
                <div class="section-content text-center">
                    <h5>Find Locations</h5>
                    <p>Locate offices and drop-off points near you.</p>
                    <a href="#" class="btn btn-outline-secondary">Search Locations</a>
                </div>
            </div>
            <div class="col-md-4 section" style="background-image: url('images/images (70).jpeg');">
                <div class="section-content text-center">
                    <h5>Shipping Rates</h5>
                    <p>Calculate the cost of shipping your items worldwide.</p>
                    <a href="#" class="btn btn-outline-secondary">Get Rates</a>
                </div>
            </div>
        </div>
    </div>
    <?php include('delivery/footer.php') ?>
</body>
</html>
