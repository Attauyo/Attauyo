<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['user_logged_in'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_logged_in'];

$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$order = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Order Details</h2>
        <?php if ($order) { ?>
            <p><strong>Tracking Number:</strong> <?= $order['tracking_number'] ?></p>
            <p><strong>Status:</strong> <?= $order['status'] ?></p>
            <p><strong>Total Amount:</strong> <?= $order['total_amount'] ?></p>
        <?php } else { ?>
            <p>No orders found.</p>
        <?php } ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
