<?php
session_start();
include('../config/db.php');

// Check if user/admin is sending the message
$sender = isset($_SESSION['user_logged_in']) ? 'user' : 'admin';
$user_id = $_POST['user_id'];
$content = $_POST['content'];
$attachment = null;

if (!empty($_FILES['attachment']['name'])) {
    $target_dir = "../uploads/";
    $attachment = $target_dir . basename($_FILES['attachment']['name']);
    move_uploaded_file($_FILES['attachment']['tmp_name'], $attachment);
}

// Insert message into database
$query = "INSERT INTO messages (user_id, sender, content, attachment) VALUES (:user_id, :sender, :content, :attachment)";
$stmt = $pdo->prepare($query);
$stmt->execute([
    ':user_id' => $user_id,
    ':sender' => $sender,
    ':content' => $content,
    ':attachment' => $attachment
]);

header('Location: ' . ($sender == 'user' ? 'dashboard.php' : 'admin_message.php'));
exit();
?>
