<?php
session_start();
include('../config/db.php'); // Include database connection

// Check if tracking number is provided
$tracking_number = $_GET['tracking_number'] ?? null;
$order_details = [];

if ($tracking_number) {
    $query = "SELECT * FROM orders WHERE tracking_number = :tracking_number";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':tracking_number' => $tracking_number]);
    $order_details = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Shipment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        #map {
            height: 400px;
            width: 100%;
        }
    </style>
</head>
<?php include('header.php'); ?>
<body>
    <div class="container mt-5">
        <h2>Track Your Shipment</h2>
        <?php if ($order_details): ?>
            <div class="card mb-4">
                <!-- Display multiple images -->
                <?php if (!empty($order_details['item_images'])): ?>
                    <?php $images = json_decode($order_details['item_images']); ?>
                    <div class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php foreach ($images as $index => $image): ?>
                                <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                                    <img src="../uploads/<?= htmlspecialchars($image) ?>" class="d-block w-100" alt="Item Image">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target=".carousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target=".carousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        </button>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title">Item Name: <?= htmlspecialchars($order_details['item_name']) ?></h5>
                    <p class="card-text">Tracking Number: <?= htmlspecialchars($order_details['tracking_number']) ?></p>
                    <p class="card-text">Sender Name: <?= htmlspecialchars($order_details['sender_name']) ?></p>
                    <p class="card-text">Receiver Name: <?= htmlspecialchars($order_details['receiver_name']) ?></p>
                    <p class="card-text">Receiver Phone Number: <?= htmlspecialchars($order_details['receiver_phone']) ?></p>
                    <p class="card-text">Receiver Email: <?= htmlspecialchars($order_details['receiver_email']) ?></p>
                    <p class="card-text">Sender Location: <?= htmlspecialchars($order_details['sender_location']) ?></p>
                    <p class="card-text">Receiver Location: <?= htmlspecialchars($order_details['receiver_location']) ?></p>
                    <p class="card-text">Current Status: <?= htmlspecialchars($order_details['current_status']) ?></p>
                    <p class="card-text">Last Status: <?= htmlspecialchars($order_details['last_status']) ?></p>
                    <p class="card-text">Next Location: <?= htmlspecialchars($order_details['next_location']) ?></p>
                    <p class="card-text">Current Location: <?= htmlspecialchars($order_details['current_location']) ?></p>
                    <p class="card-text">Shipment Date: <?= htmlspecialchars($order_details['shipment_date']) ?></p>
                    <p class="card-text">Delivery Date: <?= htmlspecialchars($order_details['delivery_date']) ?></p>
                    <p class="card-text">
                        <strong>Delivery Status:</strong> <?= htmlspecialchars($order_details['delivery_status']) ?>
                    </p>

                    <!-- Notification for specific delivery statuses -->
                    <?php if ($order_details['delivery_status'] === 'Stopped by Customs'): ?>
                        <div class="alert alert-warning">
                            <strong>Warning:</strong> Shipment is currently stopped by customs.
                        </div>
                    <?php elseif ($order_details['delivery_status'] === 'Stopped by Military'): ?>
                        <div class="alert alert-danger">
                            <strong>Alert:</strong> Shipment is currently stopped by the military.
                        </div>
                    <?php elseif ($order_details['delivery_status'] === 'Delayed'): ?>
                        <div class="alert alert-info">
                            <strong>Note:</strong> Shipment is delayed.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Map Overview -->
            <div id="map"></div>
            <script>
                // Validate latitude and longitude
                <?php if (!empty($order_details['latitude']) && !empty($order_details['longitude'])): ?>
                    var map = L.map('map').setView([<?= $order_details['latitude'] ?>, <?= $order_details['longitude'] ?>], 12);

                    // Add OpenStreetMap tile layer
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    }).addTo(map);

                    // Add a marker
                    L.marker([<?= $order_details['latitude'] ?>, <?= $order_details['longitude'] ?>])
                        .addTo(map)
                        .bindPopup('<strong>Current Location:</strong> <?= htmlspecialchars($order_details['current_location']) ?>')
                        .openPopup();
                <?php else: ?>
                    document.getElementById('map').innerHTML = "<p class='text-danger'>Map data is unavailable for this shipment.</p>";
                <?php endif; ?>
            </script>
        <?php else: ?>
            <p class="text-danger">No shipment found with the provided tracking number.</p>
        <?php endif; ?>
    </div>
<?php include('footer.php'); ?>
</body>
</html>
