<?php
session_start();
include('../config/db.php');

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $data['user_id'] ?? null;
$action = $data['action'] ?? null;

if ($user_id && ($action === 'open_chat' || $action === 'reply')) {
    $query = "UPDATE messages SET is_read = 1 WHERE user_id = :user_id AND sender = 'admin' AND is_read = 0";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    echo json_encode(['status' => 'success']);
    exit();
}

echo json_encode(['status' => 'error']);
