<!-- footer.php -->
<footer class="footer bg-dark text-white py-4">
    <div class="container text-center">
        <img src="../images/logo.png" alt="Logo" style="height: 50px;" class="mb-3"> <!-- Update the logo path -->
        <p>&copy; <?= date('Y') ?> All rights reserved.</p>
        <p>
            <a href="#" class="text-white text-decoration-none">Terms of Use</a> | 
            <a href="#" class="text-white text-decoration-none">Privacy Policy</a>
        </p>
    </div>
</footer>



<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
