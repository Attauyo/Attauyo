<?php
session_start();
include('../config/db.php');

// Ensure user is logged in
if (!isset($_SESSION['user_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Fetch user data
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->execute([':id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch user messages
$msg_query = "SELECT * FROM messages WHERE user_id = :user_id ORDER BY created_at DESC";
$msg_stmt = $pdo->prepare($msg_query);
$msg_stmt->execute([':user_id' => $user_id]);
$messages = $msg_stmt->fetchAll(PDO::FETCH_ASSOC);

// Count unread admin messages
$unread_query = "SELECT COUNT(*) FROM messages WHERE user_id = :user_id AND sender = 'admin' AND is_read = 0";
$unread_stmt = $pdo->prepare($unread_query);
$unread_stmt->execute([':user_id' => $user_id]);
$unread_count = $unread_stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #chat-widget {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background: white;
            display: none;
        }
        #chat-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
        }
        .badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: red;
            color: white;
            font-size: 12px;
            border-radius: 50%;
            padding: 5px 7px;
        }
    </style>
</head>
<?php include('../includes/header.php') ?>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h3>Welcome, <?= htmlspecialchars($user['full_name']); ?></h3>
            </div>
            <div class="card-body">
                <p><strong>Email:</strong> <?= htmlspecialchars($user['email']); ?></p>
                <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']); ?></p>
                <p><strong>Address:</strong> <?= nl2br(htmlspecialchars($user['address'])); ?></p>

                <h4 class="mt-4">Track Your Shipment</h4>
                <form action="track.php" method="GET" class="row g-3">
                    <div class="col-md-9">
                        <input type="text" name="tracking_number" class="form-control" placeholder="Enter Tracking Number" required>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-success w-100">Track</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <button id="chat-toggle" onclick="toggleChat()">💬<?php if ($unread_count > 0): ?><span class="badge" id="unread-badge"><?= $unread_count; ?></span><?php endif; ?></button>
    <div id="chat-widget">
        <div class="chat-header bg-primary text-white p-2">
            <span>Chat with Admin</span>
            <button class="btn btn-sm btn-light float-end" onclick="toggleChat()">×</button>
        </div>
        <div class="chat-messages p-3" id="chat-messages">
            <?php foreach ($messages as $message): ?>
                <div class="<?= $message['sender'] === 'admin' ? 'text-start' : 'text-end'; ?>">
                    <strong><?= $message['sender'] === 'admin' ? 'Admin' : htmlspecialchars($user['full_name']); ?>:</strong>
                    <p><?= htmlspecialchars($message['content']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="chat-input p-3">
            <form id="message-form">
                <input type="hidden" name="user_id" value="<?= $user_id; ?>">
                <input type="text" name="content" class="form-control mb-2" placeholder="Type your message..." required>
                <button type="submit" class="btn btn-primary w-100">Send</button>
            </form>
        </div>
    </div>
<?php include('../includes/footer.php') ?>
    <script>
        function toggleChat() {
            const chatWidget = document.getElementById('chat-widget');
            const unreadBadge = document.getElementById('unread-badge');

            chatWidget.style.display = chatWidget.style.display === 'block' ? 'none' : 'block';

            if (chatWidget.style.display === 'block') {
                fetch('mark_messages_read.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: <?= $user_id; ?>, action: 'open_chat' })
                }).then(() => {
                    if (unreadBadge) unreadBadge.style.display = 'none';
                });
            }
        }

        document.getElementById('message-form').addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            fetch('send_message.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(() => {
                    fetch('mark_messages_read.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ user_id: <?= $user_id; ?>, action: 'reply' })
                    });
                    location.reload();
                });
        });

        setInterval(() => location.reload(), 100000);
    </script>
</body>
</html>
