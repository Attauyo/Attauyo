<?php
session_start();
include('../config/db.php');

$user_id = $_GET['user_id'];

$query = "SELECT sender, content FROM messages WHERE user_id = :user_id ORDER BY created_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

$unread_query = "SELECT COUNT(*) AS unread_count FROM messages WHERE user_id = :user_id AND sender = 'admin' AND is_read = 0";
$unread_stmt = $pdo->prepare($unread_query);
$unread_stmt->execute([':user_id' => $user_id]);
$unread_count = $unread_stmt->fetch(PDO::FETCH_ASSOC)['unread_count'];

echo json_encode(['messages' => $messages, 'unread_count' => $unread_count]);
