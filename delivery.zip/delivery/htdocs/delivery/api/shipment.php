<?php
header('Content-Type: application/json');
require_once('../config/db.php');

$response = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tracking_number = $_POST['tracking_number'];

    // Validate input
    if (empty($tracking_number)) {
        $response = [
            'success' => false,
            'message' => 'Tracking number is required.',
        ];
        echo json_encode($response);
        exit;
    }

    // Fetch shipment details
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE tracking_number = :tracking_number");
    $stmt->execute(['tracking_number' => $tracking_number]);
    $shipment = $stmt->fetch();

    if ($shipment) {
        $response = [
            'success' => true,
            'data' => [
                'tracking_number' => $shipment['tracking_number'],
                'shipping_address' => $shipment['shipping_address'],
                'status' => $shipment['status'],
                'photo_url' => '../uploads/' . $shipment['photo_url'],
                'created_at' => $shipment['created_at'],
            ],
        ];
    } else {
        $response = [
            'success' => false,
            'message' => 'Shipment not found.',
        ];
    }
} else {
    $response = [
        'success' => false,
        'message' => 'Invalid request method.',
    ];
}

echo json_encode($response);
