<?php
// Start session for managing user state
session_start();

// Check if the user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Redirect to the login page if the user is not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

// Authenticate user credentials
function authenticateUser($email, $password) {
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        return true;
    }

    return false;
}

// Register a new user
function registerUser($username, $email, $password) {
    global $pdo;

    // Ensure the password is at least 6 characters long
    if (strlen($password) < 6) {
        return false; // Password is too short
    }

    // Password hash for storage
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    // Check if the user already exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        return false; // User already exists
    }

    // Insert new user into database
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $passwordHash);

    return $stmt->execute();
}

// Get user details
function getUserById($userId) {
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $userId);
    $stmt->execute();

    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
