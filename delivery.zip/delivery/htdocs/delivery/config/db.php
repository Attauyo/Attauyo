<?php
// Database credentials
$host = 'sql311.infinityfree.com'; // Database host
$dbname = 'if0_37872279_delivery'; // Database name
$username = 'if0_37872279'; // Database username
$password = '09058176690O'; // Database password

try {
    // Set DSN (Data Source Name)
    $dsn = "mysql:host=$host;dbname=$dbname";
    
    // Create a PDO instance
    $pdo = new PDO($dsn, $username, $password);
    
    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    // Handle connection errors
    die("Connection failed: " . $e->getMessage());
}
?>