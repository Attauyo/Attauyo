<?php
session_start();
include('../config/db.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Fetch users and messages
$query_users = "SELECT DISTINCT user_id, users.name, users.email 
                FROM messages 
                JOIN users ON messages.user_id = users.id 
                ORDER BY users.name";
$stmt_users = $pdo->prepare($query_users);
$stmt_users->execute();
$users = $stmt_users->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Admin Dashboard</h2>

        <div class="row mt-5">
            <!-- User List -->
            <div class="col-md-4">
                <h5>Users</h5>
                <ul class="list-group">
                    <?php foreach ($users as $user): ?>
                        <li class="list-group-item">
                            <a href="#" class="user-link" data-id="<?= $user['user_id']; ?>">
                                <?= htmlspecialchars($user['name']); ?> (<?= htmlspecialchars($user['email']); ?>)
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Chat Window -->
            <div class="col-md-8">
                <h5>Chat</h5>
                <div id="chat-window" class="border rounded p-3" style="height: 400px; overflow-y: auto;"></div>
                <form id="chat-form" class="mt-3">
                    <div class="mb-3">
                        <textarea class="form-control" id="chat-input" placeholder="Type a message" rows="2"></textarea>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <input type="file" id="chat-image" class="form-control">
                        <button type="submit" class="btn btn-primary">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery/dist/jquery.min.js"></script>
    <script>
        let currentUserId = null;

        // Load messages for the selected user
        $('.user-link').click(function (e) {
            e.preventDefault();
            currentUserId = $(this).data('id');
            loadMessages(currentUserId);
        });

        function loadMessages(userId) {
            $.get('admin_load_chat.php', { user_id: userId }, function (data) {
                $('#chat-window').html(data);
            });
        }

        // Handle admin message send
        $('#chat-form').submit(function (e) {
            e.preventDefault();

            const message = $('#chat-input').val();
            const file = $('#chat-image')[0].files[0];
            const formData = new FormData();

            formData.append('user_id', currentUserId);
            formData.append('message', message);
            if (file) formData.append('image', file);

            $.ajax({
                url: 'admin_send_message.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function () {
                    $('#chat-input').val('');
                    $('#chat-image').val('');
                    loadMessages(currentUserId);
                },
            });
        });

        // Auto-refresh chat
        setInterval(function () {
            if (currentUserId) {
                loadMessages(currentUserId);
            }
        }, 5000);
    </script>
</body>
</html>
