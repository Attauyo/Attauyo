<?php
require_once('../config/db.php');
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Fetch all locations
$locations = $pdo->query("SELECT * FROM locations")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Locations</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY"></script>
</head>
<body>
    <div class="container mt-4">
        <h2>Manage Locations</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Location Name</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($locations as $location): ?>
                    <tr>
                        <td><?= $location['name'] ?></td>
                        <td><?= $location['latitude'] ?></td>
                        <td><?= $location['longitude'] ?></td>
                        <td>
                            <a href="edit-location.php?id=<?= $location['id'] ?>" class="btn btn-warning">Edit</a>
                            <a href="delete-location.php?id=<?= $location['id'] ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div id="map" style="height: 400px; width: 100%;"></div>
    </div>
    <script>
        function initMap() {
            var map = new google.maps.Map(document.getElementById("map"), {
                center: { lat: 0, lng: 0 },
                zoom: 2,
            });
            // Add markers for each location
            <?php foreach ($locations as $location): ?>
                var marker = new google.maps.Marker({
                    position: { lat: <?= $location['latitude'] ?>, lng: <?= $location['longitude'] ?> },
                    map: map,
                    title: "<?= $location['name'] ?>",
                });
            <?php endforeach; ?>
        }
        google.maps.event.addDomListener(window, "load", initMap);
    </script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
