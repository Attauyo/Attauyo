<?php
session_start();
include('../config/db.php');

// Ensure admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Get user_id from the URL
$user_id = $_GET['user_id'] ?? null;

if (!$user_id) {
    header('Location: view_users.php');
    exit();
}

// Mark the messages as read when the admin replies
$query = "UPDATE messages SET is_read = 1 WHERE user_id = :user_id AND sender = 'user' AND is_read = 0";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();

// Fetch user details
$query_user = "SELECT * FROM users WHERE id = ?";
$stmt_user = $pdo->prepare($query_user);
$stmt_user->execute([$user_id]);
$user = $stmt_user->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header('Location: view_users.php');
    exit();
}

// Fetch all messages between the admin and the user
$query_messages = "SELECT * FROM messages WHERE user_id = ? ORDER BY created_at ASC";
$stmt_messages = $pdo->prepare($query_messages);
$stmt_messages->execute([$user_id]);
$messages = $stmt_messages->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reply Messages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .message-container {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 10px;
        }
        .user-message {
            background-color: #007bff;
            color: white;
            text-align: left;
        }
        .admin-message {
            background-color: #28a745;
            color: white;
            text-align: right;
        }
        .chat-window {
            max-height: 500px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h4>Chat with <?= htmlspecialchars($user['full_name']); ?></h4>
        <div class="chat-window border mb-3 p-3">
            <?php foreach ($messages as $message): ?>
                <div class="message-container <?= $message['sender'] === 'admin' ? 'admin-message' : 'user-message'; ?>">
                    <?= nl2br(htmlspecialchars($message['content'])); ?>
                    <div class="text-muted" style="font-size: 0.8em;"><?= date('d M Y, h:i A', strtotime($message['created_at'])); ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <form action="send_message.php" method="POST">
            <input type="hidden" name="user_id" value="<?= $user_id; ?>">
            <input type="hidden" name="sender" value="admin">
            <textarea name="content" class="form-control mb-2" placeholder="Type your reply..." required></textarea>
            <button type="submit" class="btn btn-primary">Send</button>
        </form>
    </div>

    <!-- Auto-Reload Chat -->
    <script>
        setInterval(function() {
            location.reload();
        }, 100000); // Reload every 1 minute
    </script>
</body>
</html>
