<?php
session_start();
include('../config/db.php');

// Ensure admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $user_id = $_POST['user_id'];
    $sender = $_POST['sender'];
    $content = $_POST['content'];

    // Handle file attachment if any
    $attachment = null;
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
        $upload_dir = '../uploads/';
        $file_name = basename($_FILES['attachment']['name']);
        $file_path = $upload_dir . $file_name;

        // Move uploaded file to the server's upload directory
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $file_path)) {
            $attachment = $file_path;
        }
    }

    // Insert the message into the database
    $query = "INSERT INTO messages (user_id, sender, content, attachment, created_at) 
              VALUES (:user_id, :sender, :content, :attachment, NOW())";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':user_id' => $user_id,
        ':sender' => $sender,
        ':content' => $content,
        ':attachment' => $attachment
    ]);

    // Redirect back to the admin messages page
    header('Location: reply_messages.php');
    exit();
}
?>
