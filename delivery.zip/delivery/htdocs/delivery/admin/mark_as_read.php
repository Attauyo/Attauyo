<?php
session_start();
include('../config/db.php');

// Ensure admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Get user_id from query parameters
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Mark all unread messages for this user as read
    $query = "UPDATE messages SET is_read = 1 WHERE user_id = :user_id AND sender = 'user' AND is_read = 0";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Redirect to the reply page
    header("Location: reply_messages.php?user_id=$user_id");
    exit();
} else {
    // If no user_id, redirect back to messages list
    header("Location: view_users.php");
    exit();
}
?>
