<?php
session_start();
include('../config/db.php');

// Ensure admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Fetch all users, their latest message, and count of unread messages
$query = "
    SELECT 
        u.id AS user_id, 
        u.full_name, 
        (SELECT content FROM messages WHERE user_id = u.id ORDER BY created_at DESC LIMIT 1) AS latest_message, 
        (SELECT created_at FROM messages WHERE user_id = u.id ORDER BY created_at DESC LIMIT 1) AS message_time,
        (SELECT COUNT(*) FROM messages WHERE user_id = u.id AND is_read = 0 AND sender = 'user') AS unread_count
    FROM users u
";
$stmt = $pdo->query($query);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users Messages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .user-card {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            position: relative;
            cursor: pointer;
            transition: all 0.3s;
        }
        .user-card:hover {
            background-color: #f8f9fa;
        }
        .latest-message {
            font-size: 0.9em;
            color: #555;
        }
        .message-time {
            font-size: 0.8em;
            color: #aaa;
        }
        .badge {
            position: absolute;
            top: 10px;
            right: 15px;
            background-color: #dc3545;
            color: white;
            font-size: 0.8em;
            border-radius: 50%;
            padding: 5px 8px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>All Users Messages</h2>
        <div id="users-container">
            <?php if (count($users) > 0): ?>
                <?php foreach ($users as $user): ?>
                    <div class="user-card" onclick="redirectToReply(<?= $user['user_id']; ?>)">
                        <h5 class="mb-1"><?= htmlspecialchars($user['full_name']); ?></h5>
                        <p class="latest-message">
                            <?= htmlspecialchars($user['latest_message'] ?? 'No messages yet'); ?>
                        </p>
                        <span class="message-time">
                            <?= $user['message_time'] ? date('d M Y, h:i A', strtotime($user['message_time'])) : ''; ?>
                        </span>
                        <?php if ($user['unread_count'] > 0): ?>
                            <span class="badge"><?= $user['unread_count']; ?></span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No users found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // Redirect to reply page
        function redirectToReply(userId) {
            window.location.href = `reply_messages.php?user_id=${userId}`;
        }

        // Auto-refresh the page every 20 seconds
        setInterval(function() {
            location.reload();
        }, 100000);
    </script>
</body>
</html>
