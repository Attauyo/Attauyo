<?php
session_start();
include('../config/db.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Fetch all orders for display
$query = "SELECT * FROM orders";
$stmt = $pdo->prepare($query);
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Shipments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Manage Shipments</h2>

        <!-- Button to Create Shipment -->
        <div class="mb-3 text-end">
            <a href="create_shipment.php" class="btn btn-success">Create Shipment</a>
        </div>

        <!-- Orders Table -->
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Tracking Number</th>
                    <th>Item Name</th>
                    <th>Current Status</th>
                    <th>Delivery Status</th>
                    <th>Sender Name</th>
                    <th>Receiver Name</th>
                    <th>Receiver Phone Number</th>
                    <th>Receiver Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['tracking_number']) ?></td>
                        <td><?= htmlspecialchars($order['item_name']) ?></td>
                        <td><?= htmlspecialchars($order['current_status']) ?></td>
                        <td><?= htmlspecialchars($order['delivery_status']) ?></td>
                        <td><?= htmlspecialchars($order['sender_name']) ?></td>
                        <td><?= htmlspecialchars($order['receiver_name']) ?></td>
                        <td><?= htmlspecialchars($order['receiver_phone']) ?></td>
                        <td><?= htmlspecialchars($order['receiver_email']) ?></td>
                        <td>
                            <a href="manage-shipments.php?edit=<?= $order['tracking_number'] ?>" class="btn btn-primary btn-sm">Edit</a>
                            <a href="delete_shipment.php?tracking_number=<?= $order['tracking_number'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this shipment?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Edit Shipment Form -->
        <?php if (isset($_GET['edit'])): 
            $tracking_number = $_GET['edit'];
            $query = "SELECT * FROM orders WHERE tracking_number = :tracking_number";
            $stmt = $pdo->prepare($query);
            $stmt->execute([':tracking_number' => $tracking_number]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
        ?>
        <h3 class="mt-5">Edit Shipment: <?= htmlspecialchars($order['tracking_number']) ?></h3>
        <form action="manage-shipments.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="tracking_number" value="<?= htmlspecialchars($order['tracking_number']) ?>">

            <div class="mb-3">
                <label for="item_name" class="form-label">Item Name</label>
                <input type="text" class="form-control" id="item_name" name="item_name" value="<?= htmlspecialchars($order['item_name']) ?>" required>
            </div>

            <div class="mb-3">
                <label for="sender_name" class="form-label">Sender Name</label>
                <input type="text" class="form-control" id="sender_name" name="sender_name" value="<?= htmlspecialchars($order['sender_name']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="receiver_name" class="form-label">Receiver Name</label>
                <input type="text" class="form-control" id="receiver_name" name="receiver_name" value="<?= htmlspecialchars($order['receiver_name']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="receiver_phone" class="form-label">Receiver Phone Number</label>
                <input type="text" class="form-control" id="receiver_phone" name="receiver_phone" value="<?= htmlspecialchars($order['receiver_phone']) ?>" required>
            </div>
             <div class="mb-3">
                <label for="receiver_email" class="form-label">Receiver Email</label>
                <input type="text" class="form-control" id="receiver_email" name="receiver_email" value="<?= htmlspecialchars($order['receiver_email']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="sender_location" class="form-label">Sender Location</label>
                <textarea class="form-control" id="sender_location" name="sender_location" required><?= htmlspecialchars($order['sender_location']) ?></textarea>
            </div>
            <div class="mb-3">
                <label for="receiver_location" class="form-label">Receiver Location</label>
                <textarea class="form-control" id="receiver_location" name="receiver_location" required><?= htmlspecialchars($order['receiver_location']) ?></textarea>
            </div>
            <div class="mb-3">
                <label for="item_images" class="form-label">Item Images (JSON format)</label>
                <input type="file" class="form-control" id="item_images" name="item_images[]" multiple>
                <p class="mt-2">Current Images: <?= htmlspecialchars($order['item_images']) ?></p>
            </div>
            <div class="mb-3">
                <label for="current_status" class="form-label">Current Status</label>
                <input type="text" class="form-control" id="current_status" name="current_status" value="<?= htmlspecialchars($order['current_status']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="last_status" class="form-label">Last Status</label>
                <input type="text" class="form-control" id="last_status" name="last_status" value="<?= htmlspecialchars($order['last_status']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="next_location" class="form-label">Next Location</label>
                <input type="text" class="form-control" id="next_location" name="next_location" value="<?= htmlspecialchars($order['next_location']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="current_location" class="form-label">Current Location</label>
                <input type="text" class="form-control" id="current_location" name="current_location" value="<?= htmlspecialchars($order['current_location']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="latitude" class="form-label">Latitude</label>
                <input type="text" class="form-control" id="latitude" name="latitude" value="<?= htmlspecialchars($order['latitude']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="longitude" class="form-label">Longitude</label>
                <input type="text" class="form-control" id="longitude" name="longitude" value="<?= htmlspecialchars($order['longitude']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="shipment_date" class="form-label">Shipment Date</label>
                <input type="datetime-local" class="form-control" id="shipment_date" name="shipment_date" value="<?= htmlspecialchars($order['shipment_date']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="delivery_date" class="form-label">Delivery Date</label>
                <input type="datetime-local" class="form-control" id="delivery_date" name="delivery_date" value="<?= htmlspecialchars($order['delivery_date']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="delivery_status" class="form-label">Delivery Status</label>
                <select class="form-select" id="delivery_status" name="delivery_status">
                    <option value="In Progress" <?= $order['delivery_status'] === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                    <option value="Stopped by Customs" <?= $order['delivery_status'] === 'Stopped by Customs' ? 'selected' : '' ?>>Stopped by Customs</option>
                    <option value="Stopped by Military" <?= $order['delivery_status'] === 'Stopped by Military' ? 'selected' : '' ?>>Stopped by Military</option>
                    <option value="Delivered" <?= $order['delivery_status'] === 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                    <option value="Delayed" <?= $order['delivery_status'] === 'Delayed' ? 'selected' : '' ?>>Delayed</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success">Update Shipment</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
