<?php
session_start();
include('../config/db.php'); // Include database connection

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Fetch quick stats for dashboard
$query_orders = "SELECT COUNT(*) AS total_orders FROM orders";
$stmt_orders = $pdo->prepare($query_orders);
$stmt_orders->execute();
$total_orders = $stmt_orders->fetch(PDO::FETCH_ASSOC)['total_orders'];

$query_users = "SELECT COUNT(*) AS total_users FROM users";
$stmt_users = $pdo->prepare($query_users);
$stmt_users->execute();
$total_users = $stmt_users->fetch(PDO::FETCH_ASSOC)['total_users'];

$query_locations = "SELECT COUNT(*) AS total_locations FROM locations";
$stmt_locations = $pdo->prepare($query_locations);
$stmt_locations->execute();
$total_locations = $stmt_locations->fetch(PDO::FETCH_ASSOC)['total_locations'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    
    <!-- Include Bootstrap CSS via CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/styles.css" rel="stylesheet"> <!-- Custom Styles if any -->
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-users.php">Manage Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-shipments.php">Manage Shipments</a>
                    </li>
                    <!--<li class="nav-item">
                        <a class="nav-link" href="manage-locations.php">Manage Locations</a>
                    </li>-->
                    <li class="nav-item">
                        <a class="nav-link" href="view_users.php">view messages</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Welcome to Admin Dashboard</h2>
        <p>You are logged in as admin.</p>
        <div class="row">
            <div class="col-md-3">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Total Orders</div>
                    <div class="card-body">
                        <h5 class="card-title"><?= $total_orders ?> Orders</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success mb-3">
                    <div class="card-header">Total Users</div>
                    <div class="card-body">
                        <h5 class="card-title"><?= $total_users ?> Users</h5>
                    </div>
                </div>
            </div> 
                      <!--  <div class="col-md-3">
                <div class="card text-white bg-info mb-3">
                    <div class="card-header">Total Locations</div>
                    <div class="card-body">
                        <h5 class="card-title"><?= $total_locations ?> Locations</h5>
                    </div>
                </div>
            </div>
        </div> -->

        <!-- Action Links -->
        <div class="row">
        <div class="col-md-6">
                <a href="manage-users.php" class="btn btn-primary w-100 mb-3">Manage Users</a>
                      </div> 
                        <!--<div class="col-md-6">
                <a href="manage-orders.php" class="btn btn-success w-100 mb-3">Manage Orders</a>
            </div> -->
            <div class="col-md-6">
                <a href="manage-shipments.php" class="btn btn-info w-100 mb-3">Manage Shipments</a>
            </div>
            <div class="col-md-6">
                <a href="view_users.php" class="btn btn-warning w-100 mb-3">view messages</a>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS via CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
