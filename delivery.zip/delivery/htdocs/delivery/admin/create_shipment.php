<?php
session_start();
include('../config/db.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $tracking_number = $_POST['tracking_number'];
    $user_id = $_POST['user_id'];
    $sender_name = $_POST['sender_name'];
    $receiver_name = $_POST['receiver_name'];
    $receiver_phone = $_POST['receiver_phone'];
    $receiver_email = $_POST['receiver_email'];
    $item_name = $_POST['item_name'];
    $sender_location = $_POST['sender_location'];
    $receiver_location = $_POST['receiver_location'];
    $item_images = $_FILES['item_images']['name']; // Store multiple images as JSON
    $current_status = $_POST['current_status'];
    $last_status = $_POST['last_status'];
    $next_location = $_POST['next_location'];
    $current_location = $_POST['current_location'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $delivery_status = $_POST['delivery_status'];
    $shipment_date = $_POST['shipment_date'];
    $delivery_date = $_POST['delivery_date'];

    // Process image upload (store images as JSON)
    if ($item_images) {
        $target_dir = "../uploads/";
        $target_files = [];
        foreach ($_FILES['item_images']['tmp_name'] as $key => $tmp_name) {
            $file_name = basename($_FILES['item_images']['name'][$key]);
            $target_file = $target_dir . $file_name;
            move_uploaded_file($tmp_name, $target_file);
            $target_files[] = $target_file;
        }
        $item_images_json = json_encode($target_files); // Store images as a JSON array
    } else {
        $item_images_json = ""; // No images uploaded
    }

    // Insert into database
    $query = "INSERT INTO orders (tracking_number, user_id, sender_name, receiver_name, receiver_phone, receiver_email, item_name, sender_location, receiver_location, item_images, current_status, last_status, next_location, current_location, latitude, longitude, delivery_status, shipment_date, delivery_date) 
              VALUES (:tracking_number, :user_id, :sender_name, :receiver_name, :receiver_phone, :receiver_email, :item_name, :sender_location, :receiver_location, :item_images, :current_status, :last_status, :next_location, :current_location, :latitude, :longitude, :delivery_status, :shipment_date, :delivery_date)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':tracking_number' => $tracking_number,
        ':user_id' => $user_id,
        ':sender_name' => $sender_name,
        ':receiver_name' => $receiver_name,
        ':receiver_phone' => $receiver_phone,
        ':receiver_email' => $receiver_email,
        ':item_name' => $item_name,        
        ':sender_location' => $sender_location,
        ':receiver_location' => $receiver_location,
        ':item_images' => $item_images_json,
        ':current_status' => $current_status,
        ':last_status' => $last_status,
        ':next_location' => $next_location,
        ':current_location' => $current_location,
        ':latitude' => $latitude,
        ':longitude' => $longitude,
        ':delivery_status' => $delivery_status,
        ':shipment_date' => $shipment_date,
        ':delivery_date' => $delivery_date
    ]);

    header("Location: manage-shipments.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Shipment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Create Shipment</h2>
        <form action="create_shipment.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="tracking_number" class="form-label">Tracking Number</label>
                <input type="text" class="form-control" id="tracking_number" name="tracking_number" required>
            </div>
            <div class="mb-3">
                <label for="user_id" class="form-label">User ID</label>
                <input type="number" class="form-control" id="user_id" name="user_id" required>
            </div>
            <div class="mb-3">
                <label for="sender_name" class="form-label">Sender Name</label>
                <input type="text" class="form-control" id="sender_name" name="sender_name" required>
            </div>
            <div class="mb-3">
                <label for="receiver_name" class="form-label">Receiver Name</label>
                <input type="text" class="form-control" id="receiver_name" name="receiver_name" required>
            </div>
            <div class="mb-3">
                <label for="receiver_phone" class="form-label">Receiver Phone Number</label>
                <input type="text" class="form-control" id="receiver_phone" name="receiver_phone" required>
            </div>
            <div class="mb-3">
                <label for="receiver_email" class="form-label">Receiver Email</label>
                <input type="text" class="form-control" id="receiver_email" name="receiver_email" required>
            </div>
             <div class="mb-3">
                <label for="item_name" class="form-label">Item Name</label>
                <input type="text" class="form-control" id="item_name" name="item_name" required>
            </div>
            <div class="mb-3">
                <label for="sender_location" class="form-label">Sender Location</label>
                <input type="text" class="form-control" id="sender_location" name="sender_location" required>
            </div>
            <div class="mb-3">
                <label for="receiver_location" class="form-label">Receiver Location</label>
                <input type="text" class="form-control" id="receiver_location" name="receiver_location" required>
            </div>
            <div class="mb-3">
                <label for="item_images" class="form-label">Item Images</label>
                <input type="file" class="form-control" id="item_images" name="item_images[]" multiple>
            </div>
            <div class="mb-3">
                <label for="current_status" class="form-label">Current Status</label>
                <input type="text" class="form-control" id="current_status" name="current_status" required>
            </div>
            <div class="mb-3">
                <label for="last_status" class="form-label">Last Status</label>
                <input type="text" class="form-control" id="last_status" name="last_status" required>
            </div>
            <div class="mb-3">
                <label for="next_location" class="form-label">Next Location</label>
                <input type="text" class="form-control" id="next_location" name="next_location" required>
            </div>
            <div class="mb-3">
                <label for="current_location" class="form-label">Current Location</label>
                <input type="text" class="form-control" id="current_location" name="current_location" required>
            </div>
            <div class="mb-3">
                <label for="latitude" class="form-label">Latitude</label>
                <input type="text" class="form-control" id="latitude" name="latitude" required>
            </div>
            <div class="mb-3">
                <label for="longitude" class="form-label">Longitude</label>
                <input type="text" class="form-control" id="longitude" name="longitude" required>
            </div>
            <div class="mb-3">
                <label for="delivery_status" class="form-label">Delivery Status</label>
                <select class="form-select" id="delivery_status" name="delivery_status">
                    <option value="In Progress">In Progress</option>
                    <option value="Stopped by Customs">Stopped by Customs</option>
                    <option value="Stopped by Military">Stopped by Military</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Delayed">Delayed</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="shipment_date" class="form-label">Shipment Date</label>
                <input type="date" class="form-control" id="shipment_date" name="shipment_date" required>
            </div>
            <div class="mb-3">
                <label for="delivery_date" class="form-label">Delivery Date</label>
                <input type="date" class="form-control" id="delivery_date" name="delivery_date" required>
            </div>
            <button type="submit" class="btn btn-primary">Create Shipment</button>
        </form>
    </div>
</body>
</html>
