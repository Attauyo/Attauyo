<?php
session_start();
include('../config/db.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Check if tracking number is provided
if (isset($_GET['tracking_number'])) {
    $tracking_number = $_GET['tracking_number'];

    // Delete from the database
    $query = "DELETE FROM orders WHERE tracking_number = :tracking_number";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':tracking_number' => $tracking_number]);

    header("Location: manage-shipments.php");
    exit();
}
?>
