<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}

include('../config/db.php');

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Delete user
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);

    $_SESSION['message'] = "User deleted successfully.";
    header("Location: manage-users.php");
}
?>
