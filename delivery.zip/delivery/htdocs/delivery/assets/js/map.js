function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 0, lng: 0 },  // Default map center (could be dynamically changed later)
        zoom: 2,  // Initial zoom level
    });

    // Example: Add a marker for each location
    <?php foreach ($locations as $location): ?>
        const marker = new google.maps.Marker({
            position: { lat: <?= $location['latitude'] ?>, lng: <?= $location['longitude'] ?> },
            map: map,
            title: "<?= $location['name'] ?>",
        });
    <?php endforeach; ?>
}

google.maps.event.addDomListener(window, "load", initMap);
