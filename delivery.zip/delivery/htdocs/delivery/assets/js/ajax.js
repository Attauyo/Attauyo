document.addEventListener('DOMContentLoaded', function () {
    // Example: Fetch shipment data and update table dynamically
    const shipmentTable = document.querySelector('#shipmentTable');

    // Fetch shipment data using AJAX
    fetch('../api/shipment.php')
        .then(response => response.json())
        .then(data => {
            data.forEach(shipment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${shipment.tracking_number}</td>
                    <td>${shipment.shipping_address}</td>
                    <td>${shipment.status}</td>
                    <td>
                        <a href="edit-shipment.php?id=${shipment.id}" class="btn btn-warning">Edit</a>
                        <a href="delete-shipment.php?id=${shipment.id}" class="btn btn-danger">Delete</a>
                    </td>
                `;
                shipmentTable.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
});
