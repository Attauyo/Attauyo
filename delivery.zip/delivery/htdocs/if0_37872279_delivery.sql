-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql311.infinityfree.com
-- Generation Time: Mar 30, 2025 at 08:08 PM
-- Server version: 10.6.19-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37872279_delivery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'admin', 'admin', '2024-12-04 23:36:15');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `city`, `state`, `country`, `zip_code`, `created_at`) VALUES
(1, 'Los Angeles', 'California', 'USA', '90001', '2024-12-04 23:36:15'),
(2, 'San Francisco', 'California', 'USA', '94101', '2024-12-04 23:36:15');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sender` enum('user','admin') NOT NULL,
  `content` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = Unread, 1 = Read'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `sender`, `content`, `attachment`, `created_at`, `is_read`) VALUES
(54, 5, 'admin', 'Dear Herfrid Niclasen,\r\n\r\nWelcome to FedEx delivery company! We\'re thrilled to have you with us and are dedicated to making your delivery experience smooth and reliable.\r\n\r\nAt FedEx, we prioritize efficiency, safety, and transparency in handling your shipments. With real-time tracking, exceptional customer service, and secure handling, your satisfaction is our ultimate goal.\r\n\r\nShould you have any questions or require assistance, feel free to reach out to us \r\n\r\nThank you for choosing FedEx. We look forward to serving you!\r\n\r\nWarm regards.', NULL, '2024-12-10 15:43:33', 1),
(55, 6, 'admin', 'Dear Herfrid Niclasen,\r\n\r\nWelcome to FedEx delivery company! We\'re thrilled to have you with us and are dedicated to making your delivery experience smooth and reliable.\r\n\r\nAt FedEx, we prioritize efficiency, safety, and transparency in handling your shipments. With real-time tracking, exceptional customer service, and secure handling, your satisfaction is our ultimate goal.\r\n\r\nShould you have any questions or require assistance, feel free to reach out to us \r\n\r\nThank you for choosing FedEx. We look forward to serving you!\r\n\r\nWarm regards.', NULL, '2024-12-10 15:45:00', 1),
(56, 6, 'user', 'Hello. I was wondering, has the package been sent yet? And what about fee and taxes? ', NULL, '2024-12-10 20:21:56', 1),
(57, 6, 'user', 'Hello. I was wondering, has the package been sent yet? And what about fee and taxes? ', NULL, '2024-12-10 20:21:58', 1),
(58, 6, 'user', 'Hello. I was wondering, has the package been sent yet? And what about fee and taxes? ', NULL, '2024-12-10 20:22:02', 1),
(59, 6, 'admin', 'your package is still in transit as no payment has been made yet for your package to be processed for delivery.\r\n\r\nOur delivery charges ranges according to our delivery service plan: \r\n24hrs delivery plan-$1,350\r\n48hrs delivery plan-$1,050\r\n72hrs delivery plan-$850\r\n\r\nKindly choose from our delivery services plan that is more convenient for you and make all necessary payment so your package will be processed and delivered to you. \r\n\r\nThanks for choosing FedEx ', NULL, '2024-12-11 07:54:36', 1),
(60, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:12:50', 1),
(61, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:12:52', 1),
(62, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:12:55', 1),
(63, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:13:12', 1),
(64, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:13:24', 1),
(65, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:13:25', 1),
(66, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:13:25', 1),
(67, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:13:25', 1),
(68, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:13:25', 1),
(69, 6, 'user', 'Hi. What is status of the package?', NULL, '2024-12-18 01:13:28', 1),
(70, 6, 'admin', 'your package is still in transit as we are yet to receive a positive response from you regarding your payments. kindly make all necessary payment as soon as possible in order for your package to be processed and added for delivery', NULL, '2024-12-18 07:45:28', 1),
(71, 6, 'admin', 'Sir/maâ€™am \r\nWe are yet to receive a response from you regarding your package that is still on transit. Kindly get back to us as soon as possible ', NULL, '2024-12-20 05:34:49', 0),
(72, 7, 'admin', 'Bem-vindo Ã  FedEx, o seu parceiro de entrega fiÃ¡vel da FedEx!\r\n\r\nTemos o prazer de o servir com soluÃ§Ãµes de entrega rÃ¡pidas, fiÃ¡veis â€‹â€‹e seguras. Seja local ou internacional, os seus pacotes estÃ£o em boas mÃ£os. Desde o rastreio em tempo real ao suporte personalizado, garantimos que a sua remessa chega ao destino de forma eficiente.\r\n\r\nObrigado por nos escolher. Vamos colocar a sua entrega a caminho!', NULL, '2024-12-24 08:13:33', 0),
(73, 7, 'admin', 'Temos todo o prazer em ajudÃ¡-lo com as suas necessidades de envio. Poderia por favor confirmar se o pagamento da entrega foi efetuado? Ajuda-nos a garantir um processamento tranquilo e oportuno do seu pacote.\r\n\r\nSinta-se Ã  vontade para partilhar os dados de pagamento ou para nos informar se precisar de ajuda com o processo de pagamento. Obrigado por nos escolher!', NULL, '2024-12-24 08:15:14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `tracking_number` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `sender_name` varchar(255) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `receiver_phone` varchar(20) NOT NULL,
  `receiver_email` varchar(255) NOT NULL,
  `sender_location` text NOT NULL,
  `receiver_location` text NOT NULL,
  `item_images` text DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_image` varchar(255) DEFAULT NULL,
  `current_status` varchar(255) DEFAULT NULL,
  `last_status` varchar(255) DEFAULT NULL,
  `next_location` varchar(255) DEFAULT NULL,
  `current_location` varchar(255) DEFAULT NULL,
  `shipment_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `delivery_status` varchar(255) DEFAULT 'In Progress'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `tracking_number`, `user_id`, `sender_name`, `receiver_name`, `receiver_phone`, `receiver_email`, `sender_location`, `receiver_location`, `item_images`, `item_name`, `item_image`, `current_status`, `last_status`, `next_location`, `current_location`, `shipment_date`, `delivery_date`, `latitude`, `longitude`, `delivery_status`) VALUES
(8, 'FX84-PG-2024', 5, 'Kika Nazareth ', 'Helder lopes', '926480279', 'helderlopes@gmail.com', 'Barcelona, Spain ', 'rua General Humberto  Delgado n.84 cave 3 2005-154 Santarem, Portugal ', '[\"..\\/uploads\\/76881361-22ba-4bcd-a37c-ac2860a1b55f\",\"..\\/uploads\\/IMG_20241005_0811221\"]', 'Pacote de Natal lacrado ', NULL, 'Barcelona, Spain ', 'Selado ', 'Portugal ', 'Barcelona, Spain', '2024-12-23', '2024-12-24', '41.38740000', '2.16860000', 'In Progress'),
(7, 'FX28-FO-360', 4, 'Newmont Investment Limited', 'Herfrid Niclasen', '+298261073', 'niclasen85@hotmail.com', 'Istanbul,Turkey', '28 FO-360 Sandavagur, Faroe Islands.', '[\"..\\/uploads\\/IMG-20241209-WA0072.jpg\",\"..\\/uploads\\/IMG-20241209-WA0070.jpg\",\"..\\/uploads\\/IMG-20241208-WA0090.jpg\",\"..\\/uploads\\/IMG-20241208-WA0087.jpg\",\"..\\/uploads\\/IMG-20241208-WA0083.jpg\",\"..\\/uploads\\/IMG-20241208-WA0080.jpg\"]', 'GOLD BARS', NULL, 'Out for Delivery', 'Awaiting Dispatch', 'Greece (Aegean Sea)', 'Istanbul, Turkey', '2024-12-10', '2024-12-23', '41.01513700', '28.97953000', 'In Progress');

-- --------------------------------------------------------

--
-- Table structure for table `orders_backup`
--

CREATE TABLE `orders_backup` (
  `id` int(11) NOT NULL DEFAULT 0,
  `tracking_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `sender_name` varchar(255) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `sender_location` text NOT NULL,
  `receiver_location` text NOT NULL,
  `item_images` text DEFAULT NULL,
  `item_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `item_image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `current_status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `last_status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `next_location` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `current_location` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `shipment_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `delivery_status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'In Progress'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders_backup`
--

INSERT INTO `orders_backup` (`id`, `tracking_number`, `user_id`, `sender_name`, `receiver_name`, `sender_location`, `receiver_location`, `item_images`, `item_name`, `item_image`, `current_status`, `last_status`, `next_location`, `current_location`, `shipment_date`, `delivery_date`, `latitude`, `longitude`, `delivery_status`) VALUES
(1, 'TRACK123456', 1, '', '', '', '', NULL, 'Electronics Item', 'uploads/item1.jpg', 'In Transit', 'Dispatched from Warehouse', 'City Hub', 'Main Warehouse', '2024-11-24', '2024-11-29', '37.77492900', '-122.41941600', 'In Progress'),
(2, 'TRACK123457', 2, '', '', '', '', NULL, 'Clothing Package', 'uploads/item2.jpg', 'Delivered', 'Out for Delivery', NULL, 'Customer Address', '2024-11-20', '2024-11-22', '40.71277600', '-74.00597400', 'In Progress'),
(3, 'TRACK001', NULL, '', '', '', '', NULL, 'Gift card ', '../uploads/images (47).jpeg', 'In transit ', 'Dispatch from the company ', 'Portugal ', 'Barcelona, Spain', '2024-12-03', '2024-12-08', '41.38879000', '2.15899000', 'Stopped by Military');

-- --------------------------------------------------------

--
-- Table structure for table `shipments`
--

CREATE TABLE `shipments` (
  `id` int(11) NOT NULL,
  `tracking_number` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `current_status` varchar(255) NOT NULL,
  `current_location` varchar(255) NOT NULL,
  `shipment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `shipments`
--

INSERT INTO `shipments` (`id`, `tracking_number`, `user_id`, `current_status`, `current_location`, `shipment_date`, `updated_at`) VALUES
(1, 'TRACK001', 1, 'In Transit', 'Los Angeles, CA', '2024-11-20 10:30:00', '2024-12-04 23:36:15'),
(2, 'TRACK002', 2, 'Delivered', 'New York, NY', '2024-11-15 14:00:00', '2024-12-04 23:36:15'),
(3, 'TRACK003', 3, 'Out for Delivery', 'Chicago, IL', '2024-11-24 08:00:00', '2024-12-04 23:36:15');

-- --------------------------------------------------------

--
-- Table structure for table `shipment_updates`
--

CREATE TABLE `shipment_updates` (
  `id` int(11) NOT NULL,
  `shipment_id` int(11) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tracking_assignments`
--

CREATE TABLE `tracking_assignments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tracking_number` varchar(255) NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `phone`, `address`, `password`, `created_at`) VALUES
(1, 'john_doe', 'john doe', 'john@example.com', '1234567890', '123 Elm Street', 'password1234', '2024-12-04 23:36:15'),
(2, 'jane_smith', 'jane smith', 'jane@example.com', '0987654321', '456 Oak Avenue', 'password456', '2024-12-04 23:36:15'),
(5, 'oliverbassey2020@gmail.com', 'Bassey Oliver', 'oliverbassey2020@gmail.com', '+2349058176690', 'Lagos Nigeria', '090581', '2024-12-08 06:23:00'),
(6, 'Herfridniclasen', 'Herfrid Niclasen ', 'niclasen85@hotmail.com', '+298 261073', 'Steigarbrekka 28\r\nFO-360 Sandavagur \r\nFaroe Islands', 'steigarbrekka28', '2024-12-10 14:39:48'),
(7, 'Helder', 'Helder Miguel Dias Lopes', 'helderlopes@gmail.com', '+926480279', 'rua General Humberto  Delgado n.84 cave 3 2005-154 Santarem, Portugal ', '1234', '2024-12-23 21:55:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tracking_number` (`tracking_number`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `shipments`
--
ALTER TABLE `shipments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tracking_number` (`tracking_number`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `shipment_updates`
--
ALTER TABLE `shipment_updates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shipment_id` (`shipment_id`);

--
-- Indexes for table `tracking_assignments`
--
ALTER TABLE `tracking_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tracking_number` (`tracking_number`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `shipments`
--
ALTER TABLE `shipments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shipment_updates`
--
ALTER TABLE `shipment_updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tracking_assignments`
--
ALTER TABLE `tracking_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
